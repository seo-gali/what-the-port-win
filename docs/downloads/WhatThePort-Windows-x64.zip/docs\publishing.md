# Windows 다운로드·소개 페이지

- 구성: 의존성 없는 정적 HTML / CSS / JavaScript
- 공개 루트: `docs/`; `docs/.nojekyll`로 Jekyll 생략
- 준비: 정식 배포는 `scripts/prepare-site.ps1`에서 신뢰된 서명·타임스탬프 확인. 미서명 시험 배포만 `-AllowUnsigned` 명시
- 로컬 미리보기: `node scripts/serve-site.mjs` → `http://127.0.0.1:4173`
- 다운로드: 기본 `docs/downloads/WhatThePort.exe`, 선택 CLI `docs/downloads/WhatThePort-Windows-x64.zip` — 실제 다운로드를 위해 Git 추적 대상 포함
- 다운로드 URL은 고정하고 사이트의 저장 이름은 `WhatThePort-v1.1.6.exe`, `WhatThePort-v1.1.6-Windows-x64.zip`처럼 실제 버전을 포함한다. `prepare-site.ps1`이 EXE·ZIP 버전 일치를 확인한 뒤 홈·가이드의 저장 이름과 체크섬 파일명을 함께 갱신한다.
- 내용: 홈, 기능·화면 소개, 이미지 사용 가이드, 라이선스, 404, 고정 헤더·모바일 메뉴, 단일 EXE·선택 ZIP·체크섬
- 배포: GitHub Pages의 main / docs. 외부 쓰기·퍼블리싱은 [작업 순서와 승인](../CODING_STANDARDS.md#작업-순서와-승인)을 따르며, 이미 승인된 범위는 다시 묻지 않음

실제 호스팅 적용 시 HTTPS, CSP, nosniff, Referrer-Policy 및 실제 HTTP 404 매핑 확인 필요. 로컬 서버의 헤더 설정은 `scripts/serve-site.mjs` 기준. 생산용 웹 서버로 사용하지 않음.

## GitHub Pages 설정

저장소 **Settings → Pages → Build and deployment → Deploy from a branch → main → /docs → Save**.

공개 주소: `https://seo-gali.github.io/what-the-port-win/`.
GitHub 저장소의 `blob/main/docs/index.html` 링크는 소스 보기 주소이며 웹사이트 주소와 별개.

현재 404의 복귀·스타일 경로는 `/what-the-port-win/` 기준. 저장소 이름 변경이나 사용자 지정 도메인 적용 시 `404.html`과 미리보기·검증 스크립트의 prefix 변경 필요.

기준: [GitHub 공식 게시 소스 설정 안내](https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site).

## 검색 노출

| 항목 | 기준 |
|---|---|
| HTML | 본문·탐색·다운로드 링크를 정적 HTML로 제공한다. JavaScript는 화면 조작을 보조하며 별도 SSR 서버는 필요하지 않다. |
| 대표 주소 | 홈은 공개 루트 `/what-the-port-win/`, 가이드·라이선스는 각 HTML 주소를 canonical로 사용한다. |
| 사이트맵 | `scripts/update-sitemap.ps1`이 공개 HTML에서 `docs/sitemap.xml`을 생성한다. 페이지 추가·삭제 후 재생성해 함께 커밋한다. 앱 배포 준비에서도 자동 실행하며 부정확한 `lastmod`는 넣지 않는다. |
| robots.txt | 도메인 루트 `https://seo-gali.github.io/robots.txt`만 적용된다. 404이면 크롤링 제한이 없다. 프로젝트 하위에는 만들지 않는다. 루트 사이트 운영 시 Googlebot을 허용하고 사이트맵 주소를 등록한다. |
| 색인 제외 | 정상 페이지에는 `noindex`·`nofollow`를 넣지 않는다. 404의 `noindex`는 유지한다. 404·Google 소유권 확인 파일은 사이트맵에서 제외하고 소유권 확인 파일 내용은 보존한다. |
| 링크·404 | HTTPS 최종 주소로 직접 연결한다. 없는 주소는 자동 리디렉션 없이 HTTP 404와 홈·다운로드·가이드 링크를 제공한다. |

Search Console 제출은 사용자가 직접 진행한다. 로그인된 소유자·전체 사용자로 이 사이트의 URL 접두어 속성 → **Sitemaps**에서 `https://seo-gali.github.io/what-the-port-win/sitemap.xml`을 제출하고 가져오기 결과를 확인한다. 폐기된 Google sitemap ping은 사용하지 않으며 제출이 색인 등록을 보장하지는 않는다.

기준: [Google의 JavaScript 검색 안내](https://developers.google.com/search/docs/crawling-indexing/javascript/javascript-seo-basics), [사이트맵 생성·제출](https://developers.google.com/search/docs/crawling-indexing/sitemaps/build-sitemap), [robots.txt 위치·응답 처리](https://developers.google.com/crawling/docs/robots-txt/robots-txt-spec).

## 준비·검증

버전은 `src/Core/AppVersion.cs`, 변경 기록은 루트 `CHANGELOG.md`에서 관리한다. 추가·개선·수정을 구분하고, 테스트 후 동일 버전의 단일 EXE·ZIP·검증 보고서·체크섬을 함께 게시한다. ZIP에는 `docs/CHANGELOG.md`를 포함한다. 검증된 커밋에 `v1.1.0` 형식의 태그를 붙인다. 버전 태그와 GitHub Releases 게시물은 별개이며, Releases에 게시할 때는 같은 변경 기록과 검증된 파일을 사용한다.

공개 앱 배포는 GitHub Release에 버전이 붙은 EXE·선택 ZIP과 `SHA256SUMS.txt`를 첨부한다. 빌드·코드 서명을 마친 최종 EXE를 VirusTotal 등에 제출하고, SHA-256으로 조회할 수 있는 보고서 링크·검사 시각·탐지 수를 Release 설명에 함께 공개한다. 탐지가 있으면 그대로 기록하고, 원인·제조사 판정 없이 오탐 또는 안전으로 단정하지 않는다. ZIP 내부 실행 파일은 별도 검사 대상이다. 파일을 변경하면 해시와 검사 결과도 갱신한다. 시크릿·개인 파일은 제출하지 않는다.

Release·사이트·백신 검사에는 동일한 바이트를 사용한다. 재현 가능한 검사 기록은 `docs/downloads/VIRUSTOTAL-<버전>.json`처럼 버전별로 보관하고 README에서 보고서와 체크섬을 연결한다. 검사 미완료나 로그인·권한 부족으로 게시하지 못한 상태는 완료로 처리하지 않는다.

사이트의 HTML·CSS·JavaScript만 변경하면 기존 다운로드 파일을 유지하고 아래 검사만 실행한다. Markdown 문서만 변경하면 상대 경로·앵커·명령과 설명의 정합성을 확인한다.

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File scripts/update-sitemap.ps1
node scripts/serve-site.mjs
# 다른 터미널
node scripts/check-site.mjs
```

프로젝트 경로 미리보기: `http://127.0.0.1:4173/what-the-port-win/`. 검사 스크립트는 서버를 시작하지 않으므로 먼저 4173 포트에서 미리보기 서버를 실행한다. 전역 `fetch`·`WebSocket`을 제공하는 Node.js와 `C:/Program Files/Google/Chrome/Application/chrome.exe`의 Chrome이 필요하다. 다운로드 EXE·ZIP·체크섬·정보 JSON도 검사하므로 기존 배포 파일이 있어야 한다.

앱이나 다운로드 산출물을 변경할 때만 [변경 범위별 검증](../CODING_STANDARDS.md#검증)과 배포 준비를 추가한다. 단일 EXE는 `scripts/test-single-file.ps1`, ZIP·게시 준비 스크립트는 `scripts/test-package.ps1`로 검사한다. 선택 CLI ZIP을 갱신해야 하거나 준비할 ZIP이 없을 때만 `scripts/package.ps1`을 실행한다. `scripts/prepare-site.ps1`은 단일 EXE를 빌드하고 공개 다운로드·검증 보고서를 갱신하므로 사이트 검사만을 위해 실행하지 않는다.

정식 배포 준비는 신뢰된 서명·타임스탬프를 갖춘 산출물로 `powershell -NoProfile -ExecutionPolicy Bypass -File scripts/prepare-site.ps1`을 실행한다. 미서명 시험 배포가 승인된 경우에만 `-AllowUnsigned`를 명시한다. 로컬 준비와 공개 게시는 별개이며, 게시에는 위 승인 규칙을 적용한다.
검증 범위: 320·360·390·430·768·1024·1440px의 홈·가이드·라이선스·404, 가로 넘침, 스크롤 시 헤더 고정, 키보드 메뉴·탭, 목차 이동 위치, 이미지 확대·Esc 복귀, 대체 텍스트, 라이선스 원문 일치, 로컬 링크, 중첩 주소 404, EXE·ZIP·SHA-256. 휴대폰 구간은 Chrome의 모바일·터치 에뮬레이션으로 확인한다. 실제 iOS Safari·Android 기기 검증은 별도다.

사이트 이미지는 최신 앱의 데모 캡처를 `docs/images/`에 두고 준비 스크립트로 `docs/assets/images/`에 복사한다. 한국어 9개 화면(최소·최대 크기와 설정 하단 포함), 영어 설정·종료 결과 예시, 보호 사유 도움말을 사용한다. README 소개 이미지 `docs/images/cover.jpg`는 실제 앱 캡처와 구분한 생성 일러스트다.

홈페이지는 원래 README 일러스트의 어두운 네이비 배경과 청록·보라·분홍 네온 서버를 디자인 기준으로 삼는다. 홈페이지 전용 레이아웃은 `assets/home.css`, 공통 페이지 색상과 탐색은 `assets/site.css`에서 관리한다. 홈페이지의 `assets/images/hero-servers.webp`는 원래 README 그림을 참조해 제작한 투명 배경 일러스트의 무손실 WebP이며 앱 패키지에는 포함하지 않는다. 첫 화면의 이미지이므로 지연 로딩하지 않는다. 제목·버튼·설명은 이미지에 넣지 않고 반응형 HTML로 표시한다. README의 원본 표지는 별도로 유지한다.

첫 화면 서버 이미지의 전송 예산은 1MiB다. 사이트 검사는 이 예산과 이미지 MIME·원본 크기·초기 로딩을 확인한다.

가이드는 실행·조회·설정·정리에 필요한 동작을 짧게 설명하고 세부 옵션은 접힌 영역에 둔다. 이미지 링크는 JavaScript를 사용하면 원본 크기의 확대 창을 열고, 스크립트가 꺼져 있으면 이미지 파일로 이동한다. 라이선스 전문은 `license.html`에 표시하며 `LICENSE.txt` 다운로드도 제공한다. 사이트 검사에 사용한 `artifacts/site-browser-qa-*` 임시 Chrome 프로필은 검사 종료 시 제거한다.

가이드 본문은 문장 끝 마침표 뒤에서 줄을 바꾼다. 파일명·버전·명령의 마침표는 유지한다. 가이드 이미지의 표시 크기는 기존의 70%로 줄이고, 확대 보기에서는 원본 크기를 유지한다.

앱 패키지에는 Markdown 사용 문서·이미지만 포함. 사이트 다운로드 ZIP의 자기 포함·반복 빌드 시 용량 증가 방지.
로컬 서버의 보안 응답 헤더는 GitHub Pages에 자동 이전되지 않음.

Chrome 다운로드 경고, 공인 코드 서명, ZIP 내용 유지와 Google 검토 절차: [다운로드 보안 절차](download-security.md). 웹사이트 수정만으로 공개 ZIP을 재생성하지 않는다.
