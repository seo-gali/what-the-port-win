# 다운로드·인증서 보안 점검

현재 기본 다운로드는 단일 GUI EXE이며 터미널용 ZIP도 선택할 수 있다. 두 다운로드 모두 HTTPS로 제공하지만 Authenticode 서명은 없다. 단일 EXE는 압축 해제 없는 실행 편의를 위한 것으로, 확장자 변경만으로 Chrome 경고가 사라진다는 뜻은 아니다. SHA-256·ZIP 구성 검사와 악성코드 검사, Chrome 평판은 서로 다른 결과다. 무결성 검사를 통과했다고 안전 판정 또는 경고 해제를 주장하지 않는다.

## 2026-11-07 · v1.1.7 파일 아이콘

일반 GUI·단일 EXE에 기존 사이트의 금색 점 모양을 Windows ICO 리소스로 내장했다. 16–256px 크기를 포함하고 아이콘 파일을 단일 EXE 빌드 캐시 입력에도 추가했다. README 상단의 중복 다운로드 링크를 제거했다. 트레이 동작·필터·종료 보호·설정 저장 방식은 유지한다.

최종 EXE·ZIP은 새 해시로 구분하며 [파일 정보](downloads/EXE-INFO.json), [체크섬](downloads/SHA256SUMS.txt), [기능 검증](downloads/FUNCTIONAL-TESTS-1.1.7.json)을 함께 갱신한다. 서명 없는 시험 빌드이며 VirusTotal·IObit 재검사 전이다. [현재 검사 상태](downloads/ANTIVIRUS-INFO.json)에 `NotScanned`로 표시한다. 이전 버전의 검사 결과를 새 파일의 판정으로 사용하지 않는다.

## 2026-11-07 · v1.1.6 다운로드 교체

빈 목록의 제목을 `현재 필터에 맞는 서버 없음`으로 바꾸고 중복 설명을 제거했다. 표시 필터·서버 종료·자동 실행·프로세스 보호 정책은 변경하지 않았다. 단일 EXE와 CLI 포함 ZIP을 같은 버전으로 다시 준비한다.

1.1.6은 Authenticode 서명이 없는 시험 빌드이며 **VirusTotal·IObit 재검사 전**이다. 이전 1.1.5의 검사 결과와 소스 일치 비교는 새 파일의 판정으로 사용하지 않는다. 현재 파일 정보·체크섬·검사 상태는 [EXE 정보](downloads/EXE-INFO.json), [SHA-256](downloads/SHA256SUMS.txt), [검사 상태](downloads/ANTIVIRUS-INFO.json), [기능 검증](downloads/FUNCTIONAL-TESTS-1.1.6.json)에서 확인한다. GitHub Release 게시물은 사용자가 직접 게시한다.

아래는 이전 버전과 당시 파일 해시에 대한 기록이다.

## 2026-11-05 · v1.1.5 공개 배포 점검

당시 1.1.5 공개 EXE와 동일한 파일을 VirusTotal에 제출했다. SHA-256은 `323400c20142bf8dbf49aa5f99be4c604b79ee557abed35ea26a0b714961ce99`이며, 분석 시각은 2026-11-05 11:23:31 UTC다. **71개 엔진 중 5개 탐지**, 66개 미탐지이며 추가 4개 엔진은 파일 형식을 처리하지 못했다.

| 엔진 | 탐지명 |
|---|---|
| Bkav Pro | `W32.Malware.EF63D6B5` |
| CrowdStrike Falcon | `Win/malicious_confidence_70% (D)` |
| Elastic | `Malicious (moderate Confidence)` |
| McAfee Scanner | `Ti!323400C20142` |
| SecureAge | `Malicious` |

[SHA-256으로 조회하는 VirusTotal 보고서](https://www.virustotal.com/gui/file/323400c20142bf8dbf49aa5f99be4c604b79ee557abed35ea26a0b714961ce99/detection) · [검사 당시 기록](downloads/VIRUSTOTAL-1.1.5.json) · [배포 파일 체크섬](downloads/SHA256SUMS.txt).

오탐 여부와 탐지 원인은 미확정이다. 이전 IObit 수동 검사 0건과 이번 VirusTotal 결과는 서로 다른 검사 기록이며, 한쪽 결과로 다른 쪽을 무효화하지 않는다. 제조사 검토는 제출하지 않았다. 이 보고서는 단일 GUI EXE에 대한 결과이며 ZIP과 내부 실행 파일의 VirusTotal 결과를 대신하지 않는다. 보고서는 이후 재분석으로 달라질 수 있고, 파일을 재빌드하거나 서명해 해시가 바뀌면 새 파일을 검사해야 한다.

GitHub에는 `v1.1.5` 태그가 있지만 Release 게시물은 없다. 버전이 붙은 EXE·ZIP과 `SHA256SUMS.txt`, 검사 기록·설명을 로컬에 준비했으며 GitHub 로그인 부재로 게시하지 못했다. 코드 서명이 없는 시험 빌드 상태를 유지하며 안전 확인 완료로 안내하지 않는다.

## 2026-11-05 · 새 빌드와 ZIP판 비교

이 점검 당시 앱 소스와 빌드 입력은 `v1.1.5` 태그 이후 변경되지 않았다. 같은 PC의 Windows 내장 빌드 도구로 입력 파일 31개를 별도 폴더에 복사해 새 EXE를 만들었다. 기존 배포 EXE·ZIP과 메모리 읽기·서버 종료 기능은 변경하지 않았다.

두 EXE의 크기는 717,824바이트로 같고 48바이트가 다르다. 차이는 PE 빌드 시각, .NET 모듈 ID(MVID), 같은 ID가 들어간 컴파일러 생성 타입 이름에만 있었다. 이 세 필드를 제외한 **파일 전체가 바이트 단위로 일치**했다. 코드 위치의 바이트와 타입 이름 접두사를 바꾸는 자체 검증에서는 비교가 실패하는 것도 확인했다. 독립된 PC에서 재현한 결과나 악성코드 부재 증명은 아니다. [입력 해시·제외 범위·비교 기록](downloads/BUILD-COMPARISON-1.1.5.json).

새 EXE의 SHA-256은 `a59d612e8b152f84ed9d40cb70d7c86c454bee8c96cff5f1611f6740e14400d6`이다. 이 파일은 대조용으로만 보관하며 공개 다운로드를 교체하거나 VirusTotal에 제출하지 않았다.

공개 ZIP 자체와 내부 GUI·Core DLL·CLI를 각각 VirusTotal에 제출했다. 내부 파일은 배포 메타데이터의 SHA-256과 일치함을 확인한 뒤 제출했다. 아래 시각은 UTC이며 단일 EXE는 같은 날의 기존 보고서를 사용했다.

| 파일 | 검사 시각 | 탐지 / 판정 엔진 | 보고서 |
|---|---|---|---|
| 단일 GUI EXE | 11:23:31 | **5/71** | [조회](https://www.virustotal.com/gui/file/323400c20142bf8dbf49aa5f99be4c604b79ee557abed35ea26a0b714961ce99/detection) |
| ZIP 내부 GUI EXE | 12:31:14 | **3/71** | [조회](https://www.virustotal.com/gui/file/609debb9845e6e5e98a737de6f84d24a7fe00265323ce878e9d85bcca75dd236/detection) |
| ZIP 내부 Core DLL | 12:33:49 | **3/71** | [조회](https://www.virustotal.com/gui/file/7df692cf184e5e568de1cbf4da12f9da66d2f333583b82f412e70947f528583a/detection) |
| ZIP 내부 CLI EXE | 12:34:56 | **7/70** | [조회](https://www.virustotal.com/gui/file/afd1d107ebe78356bb2570da2f7004b3c2b8af35b405741d61c89bfad87379fd/detection) |
| ZIP 전체 | 12:35:28 | **5/67** | [조회](https://www.virustotal.com/gui/file/a5c1adc9c5c5cc37ca9f6eb646694aaaf765f2007670c99f8efc26ecaec46579/detection) |

GUI는 Bkav·McAfee·SecureAge, Core DLL은 Bkav·Cynet·DeepInstinct, CLI는 Bkav·Elastic·Google·McAfee·SecureAge·Trapmine·Varist가 탐지했다. ZIP은 Bkav·DeepInstinct·Elastic·Google·Varist가 탐지했다. [파일별 해시·탐지명·엔진 상태 기록](downloads/VIRUSTOTAL-ZIP-1.1.5.json).

파일 형식을 처리하지 못한 엔진은 GUI·Core·CLI에서 각 4개, ZIP에서 7개다. CLI와 ZIP은 엔진 실패도 각 1개이며 위 분모에서 제외된다. 기록은 공개 UI 관측값이며 VirusTotal API 원본 응답은 아니다.

**ZIP판에서도 탐지가 있으므로 단일 EXE 구성만의 문제로 한정할 근거는 없다.** 검사 시각과 엔진 구성이 달라 점수 차이로 특정 기능의 원인을 확정할 수도 없다. 메모리 읽기·서버 종료는 필수 기능으로 유지한다. 업체별 재검토 요청은 보내지 않았으며 오탐 여부·정확한 탐지 원인·코드 서명은 여전히 해결되지 않았다.

### 같은 날 기능 재검증

`scripts/test.ps1`과 `scripts/test-single-file.ps1`을 순서대로 실행했고 두 명령 모두 종료 코드 0이었다. 일반판·단일 EXE에서 각각 Core 148개·UI 215개가 통과했다. CLI 조회·오류 처리, 트레이·창 시작, 중복 실행·숨긴 창 복귀, 화면 표시·숨김 상태의 그래프 갱신과 단일 EXE의 내장 폰트·라이선스·외부 파일 없는 실행을 확인했다.

검사는 변경되지 않은 앱 소스로 생성한 테스트 빌드를 대상으로 했다. 실제로 검사한 파일 해시는 [기능 테스트 기록](downloads/FUNCTIONAL-TESTS-1.1.5.json)에 남겼다. 기존 공개 EXE·ZIP은 교체하지 않았으며 기능 통과가 VirusTotal 탐지 해제나 안전 판정을 뜻하지 않는다. 실제 Windows 재로그인과 IObit Startup Smart Scan은 이번 검증에 포함하지 않았다.

## 2026-10-22 인증서 보안 점검

대상은 What the Port Windows **1.1.2**와 공개 배포 경로다. 아래 결과는 해당 날짜의 읽기 전용 점검 기록이며, 이후 인증서 갱신·OS 업데이트 상태는 다시 확인해야 한다. 인증서 검사와 악성코드 검사, 코드 서명, Secure Boot 상태를 구분한다.

### eMudhra / emSign 중간 CA 개인 키 유출

Cloudflare는 2026-10-20 공지에서 eMudhra 중간 인증서 8개의 키가 손상되어 공격자가 다른 도메인의 인증서를 위조할 수 있다고 설명했다. 실제 방어 여부는 OS·브라우저·런타임·자체 신뢰 저장소 중 어떤 검증 경로를 쓰는지에 따라 다르다. [Cloudflare 공식 공지와 개발자 조치](https://blog.cloudflare.com/emudhra-certificate-compromise/).

| 대상 | 확인한 내용 | 판단 |
|---|---|---|
| 다운로드 사이트 `seo-gali.github.io` | `*.github.io` → Let's Encrypt YR1 → Root YR → ISRG Root X1. 당시 서버 인증서 만료일은 2026-12-29 UTC | 확인한 체인에 eMudhra/emSign 없음. HTTPS 기본 검증과 온라인 폐기 확인을 포함한 Windows 체인 검사 통과 |
| 소스 저장소 `github.com` | Sectigo Public Server Authentication CA DV E36 → Root E46. 당시 서버 인증서 만료일은 2026-11-29 UTC | 확인한 체인에 eMudhra/emSign 없음. 같은 방식의 체인 검사 통과 |
| 앱·빌드 의존성 | .NET Framework 4.8 / WPF. 앱 자체의 외부 HTTPS API 클라이언트·자체 CA 묶음 없음. Python `certifi`, Go, Electron, NSS를 앱에 포함하지 않음 | 해당 패키지의 프로젝트 내 교체 대상은 발견하지 못함. 브라우저·외부 CLI는 각 도구의 업데이트 상태를 따로 확인 |
| 배포 EXE | 1.1.2, Authenticode `NotSigned` | 코드 서명은 미완료. 이번 CA 사고 점검을 게시자 신원 확인이나 백신 안전 판정으로 해석하지 않음 |

점검한 EXE의 SHA-256은 `38f000df3c0f6888170b1a3e4d9484cfc8d12f16f40a026d7354f3d275ef6725`다. 현재 배포 파일 정보는 [EXE 확인 정보](downloads/EXE-INFO.json)와 [SHA-256 목록](downloads/SHA256SUMS.txt)을 참고한다.

HTTPS는 인증서 검증을 끄지 않고 조회했다. 체인 검사는 `X509Chain.Build`, `RevocationMode=Online`으로 수행했고 두 호스트 모두 체인 오류가 없었다. 이는 **관측한 서버 인증서가 유효했다는 결과**다. 이 PC가 모든 eMudhra 위조 인증서를 차단하는지, 모든 사용자의 브라우저·백그라운드 도구가 패치됐는지는 검증하지 않았다. Windows와 브라우저 보안 업데이트, 별도로 사용하는 CLI·런타임의 공식 보안 업데이트를 확인해야 한다.

### Windows Secure Boot 인증서 전환

Secure Boot는 OS 부팅 단계의 신뢰 경로다. 일반 사용자 모드에서 실행하는 이 앱의 코드 서명·HTTPS와 별도로 관리한다. Microsoft는 2011년 인증서를 2023년 인증서로 전환하도록 안내한다. 미전환 장치가 즉시 부팅 불능이 된다는 뜻은 아니지만 이후 부팅 보안 업데이트·보호에 제약이 생길 수 있다. [Windows 클라이언트 공식 조치](https://learn.microsoft.com/en-us/troubleshoot/windows-client/windows-security/update-secure-boot-certificates).

Microsoft가 명시한 인증서 만료일은 다음과 같다. 특히 **Microsoft UEFI CA 2011은 2027년이 아니라 2026년 6월 27일**이다. [Microsoft 공식 인증서 일정](https://learn.microsoft.com/en-us/azure-stack/operator/secure-boot-certificates?view=azs-2601).

| 기존 인증서 | 만료일 |
|---|---|
| Microsoft Corporation KEK CA 2011 | 2026-06-24 |
| Microsoft Windows Production PCA 2011 | 2026-10-19 |
| Microsoft UEFI CA 2011 | 2026-06-27 |

점검한 개발 PC의 레지스트리에는 `UEFISecureBootEnabled=0`, `UEFICA2023Status=NotStarted`가 표시됐다. 이는 **해당 개발 PC 한 대의 관측값**이며 사용자 PC 전체에 대한 결과가 아니다. `Confirm-SecureBootUEFI`와 `Get-SecureBootUEFI`는 권한 부족으로 실패했으므로 펌웨어의 실제 인증서 등록 상태나 전환 완료 여부를 확정하지 않는다.

다음은 상태를 읽는 명령이다. 레지스트리 조회는 수행했으며, 펌웨어 명령은 관리자 권한으로 다시 확인할 필요가 있다.

```powershell
Get-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\SecureBoot\State' |
    Select-Object UEFISecureBootEnabled
Get-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\SecureBoot\Servicing' |
    Select-Object UEFICA2023Status, UEFICA2023Error
Confirm-SecureBootUEFI
([Text.Encoding]::ASCII.GetString((Get-SecureBootUEFI -Name db).Bytes)).Contains('Windows UEFI CA 2023')
([Text.Encoding]::ASCII.GetString((Get-SecureBootUEFI -Name KEK).Bytes)).Contains('Microsoft Corporation KEK 2K CA 2023')
```

필요한 조치는 제조사의 BIOS/UEFI 호환성·업데이트 안내와 Windows Update를 확인하고, 적용 후 공식 상태 지표를 다시 검사하는 것이다. 레지스트리의 상태값을 직접 바꿔 완료로 표시하거나 기존 부팅 인증서를 임의 삭제하지 않는다. 이번 점검에서는 펌웨어·신뢰 저장소·부팅 설정 변경이나 OS 업데이트 설치를 수행하지 않았다.

### 미확인·후속 항목

- 개발 PC와 사용자 환경의 eMudhra 차단 패치 적용 여부: 미확인. 정상 사이트의 HTTPS 접속 성공만으로 차단 완료를 판단하지 않는다.
- 개발 PC의 Secure Boot 2023 인증서 등록·부트 매니저 전환: 관리자 권한으로 추가 확인 필요.
- EXE 코드 서명과 기존 IObit 탐지의 제조사 판정·독립적인 악성코드 검사: 미완료. 이번 인증서 점검으로 해결됐다고 주장하지 않는다.

## 경고 구분

“일반적으로 다운로드되지 않으며 위험할 수 있습니다”는 Google Safe Browsing이 아직 충분히 알지 못하는 파일에 대한 **Uncommon downloads** 경고다. 악성코드 검출·HTTPS 혼합 콘텐츠 경고와 구분한다. Google의 평가 전까지 경고가 남을 수 있고, 서명만 추가해도 즉시 사라진다고 보장할 수 없다.

[Google의 경고 설명](https://support.google.com/chrome/answer/6261569?hl=ko) · [Search Console의 Uncommon downloads 항목](https://support.google.com/webmasters/answer/9044101?hl=ko)

## IObit `Suspicious.Startup` 보고

2026-10-21 사용자가 IObit Malware Fighter에서 1.1.0 EXE의 `Suspicious.Startup` 탐지를 보고했다. 해당 다운로드 파일은 공개 배포본과 SHA-256이 일치했다. 해시는 `07a5afd6601fc6640d2d12f5574baaba91a126d0eb8613cc6c354a4ec03e5078`이며, Authenticode 서명은 없다. 파일 일치는 악성코드 검사 통과나 오탐 확정을 뜻하지 않는다.

앱은 사용자가 설정의 Windows 로그인 시 시작을 켜고 저장할 때만 현재 사용자 시작프로그램 폴더에 `What the Port.lnk`를 생성한다. 대상은 현재 EXE와 `--background`이며, 끄고 저장하면 해당 바로가기만 삭제한다. 등록에는 Windows의 `WScript.Shell` 바로가기 API를 사용한다. 후속 로그 대조에서 탐지가 `STARTUP` 유형이었고 해당 바로가기의 제거 기록이 있음을 확인했다. 정확한 탐지 규칙·오탐 여부는 제조사가 확인하지 않았다. 점검 시 실제 시작프로그램 폴더에는 이 바로가기가 없었다.

IObit 공식 설명서의 [Report False Positive](https://www.iobit.com/product-manuals/imf-help/) 절차로 해당 파일·탐지명을 제조사에 검토 요청할 수 있다. 백신 보호 해제나 예외 추가를 해결책으로 안내하지 않는다. 제조사 검토·독립적인 악성코드 검사 결과는 아직 없으며, 새 UI 버전 배포만으로 이 탐지가 해결됐다고 주장하지 않는다.

### 2026-10-22 로컬 백신 재검사

배포 파일을 실행하지 않고 별도 검사 폴더에 복사해 설치된 IObit의 공식 우클릭 검사로 검사했다. 대상은 1.1.2 단일 EXE·ZIP과 ZIP에서 꺼낸 GUI EXE·CLI EXE·Core DLL, 비교용 1.1.0 EXE다. 각 복사본의 SHA-256을 검사 전후 확인했으며 여섯 파일 모두 유지됐다.

| 항목 | 기존 탐지 | 재검사 |
|---|---|---|
| 완료 시각 · PC 로컬 시간 | 2026-10-21 19:41:45 | 2026-10-22 20:33:40 |
| IObit 버전 / 엔진 | 13.5.0.1684 / 13.0.0.1634 | 동일 |
| IObit DB 버전 | 2637 | 2638 |
| 보고서의 BDVersion | 7.101686 · 2026-10-16 GMT | 7.101696 · 2026-10-18 GMT |
| 검사 방식 | AutoCare-Idle / Smart Scan | Manual / Right Scan |
| 검사 개체 | 108,764개 | 70개 |
| 결과 | `Suspicious.Startup` 1건 · 유형 `STARTUP` | **Completed · Threats Detected: 0** · 14초 |

실제 텍스트 보고서에서 검사 경로가 준비한 복사본 폴더와 일치함을 확인했다. 기존 보고서의 MD5 `d9f49ecd797bd21d27dfc2730cf8ef36`도 SHA-256으로 식별한 1.1.0 비교 파일과 일치했다. IObit의 시작프로그램 백업 기록과 사용자가 제공한 격리 목록 화면에는 `What the Port.lnk`의 2026-10-21 제거 기록이 있었다. 이는 기존 탐지가 자동 실행 항목 분류였다는 근거이며, EXE 내부의 감염이나 오탐 여부를 확정하는 분석은 아니다.

한계와 후속 확인:

- 재검사는 설치된 IObit의 파일 검사 결과다. 기존 시작프로그램 스마트 검사와 방식·DB 버전이 달라 시작프로그램 등록 후 재탐지 여부나 규칙 수정 여부는 확인하지 못했다. 점검을 위해 자동 실행을 다시 등록하지 않았다.
- 보고서의 BDVersion은 기록했지만 선택형 Bitdefender 엔진의 실제 활성 여부와 제조사 최신 DB 여부는 별도로 검증하지 않았다.
- Windows Defender는 `Not running`, `AntivirusEnabled=false`여서 다른 제품을 이용한 독립 검사 결과는 얻지 못했다. 보호 설정이나 서비스 상태는 변경하지 않았다.
- IObit의 **이번 검사에서 탐지되지 않았음**을 확인했다. 악성코드 부재·전체 보안 통과·기존 탐지의 오탐 확정을 뜻하지 않는다.
- 원본 로그·검사 파일 목록·해시와 제조사 요청 초안은 로컬 `artifacts/security/antivirus-review-20261022/`에 보관했다. 외부 제출과 제조사의 정확한 판정은 아직 완료하지 않았다.

### 2026-10-23 · 1.1.3 EXE 재검사

1.1.3 최종 단일 EXE를 같은 방식으로 검사했다. IObit 13.5.0.1684 · DB 2638, `Manual / Right Scan`, 2개 개체 · 12초 · **Completed · 탐지 0건**이다. 검사 전후 SHA-256은 `e89d81ec284c03fbfc855350d96dd9fe0d6b529497701bb674afc25f61a2e3ae`로 동일했다. 원본 보고서와 해시는 로컬 `artifacts/security/antivirus-review-1.1.3/`에 보관한다.

파일을 실행하거나 보호 설정·시작프로그램을 변경하지 않았다. 이번 파일 검사 결과이며, 기존 시작프로그램 탐지의 오탐 확정이나 코드 서명 완료를 뜻하지 않는다.

### 2026-10-25 · 시작프로그램 재탐지 확인

IObit의 2026-10-24 17:42:19 저장 보고서에서 `Suspicious.Startup` 재탐지를 확인했다. `AutoCare-Idle / Smart Scan`, DB 2638, 탐지 유형 `STARTUP`, 1건이며 처리 상태는 `제거됨`이다. 대상은 `artifacts/single-file/WhatThePort.exe`로, 파일 버전은 1.1.3이다. 보고서의 MD5 `5cc1159a82b6d2ae42aa8144d31214a0`가 조사 당시 파일과 일치하고, SHA-256은 `c17c906d01b25f6ca400a914bd98e5ef9b978791b34489f27d148f981f15fe97`이다. 앞서 검사한 1.1.3 최종 배포본과는 다른 파일이다.

확인 시 해당 EXE는 남아 있고 `What the Port.lnk`는 없었다. 보고서의 `제거됨`을 EXE 삭제나 감염 확정으로 해석하지 않는다. 현재 다운로드의 1.1.4 EXE와 미출시 강제 종료 빌드도 이번 탐지 대상과 해시가 다르다. 탐지된 파일은 여전히 미서명이며, 서명 부재가 이 규칙의 원인인지는 확인되지 않았다.

세 파일의 해시를 보존하고 공식 우클릭 파일 검사를 요청했지만, 이번 점검에서는 대상 경로가 일치하는 완료 보고서를 확보하지 못했다. 검사 통과로 기록하지 않는다. Defender도 `Not running`이어서 독립 검사는 미완료다. 이 파일 검사 단계에서는 시작프로그램 재등록·백신 예외 추가·보호 해제를 하지 않았다.

원인 조사에서 IObit의 `StaupscanBack/What the Port.lnk`를 읽기 전용으로 확인했다. 대상은 위에서 해시를 대조한 개발용 EXE이며, 인자는 `--background`, 작업 폴더는 해당 EXE의 폴더다. 앱의 자동 실행 등록 코드와 같은 구성이다. 이 백업은 탐지된 EXE와 자동 실행 항목의 연결을 보여주지만, IObit이 어떤 특성 때문에 그 항목을 의심했는지까지 설명하지는 않는다.

시작프로그램 폴더의 바로가기는 [Microsoft가 안내하는 자동 실행 방식](https://support.microsoft.com/en-au/windows/experience/startup-boot/configure-startup-applications-in-windows)이다. 설치된 IObit의 `English.lng:802`는 고급 검사의 범위를 시작 항목·서비스·예약 작업으로 설명한다. `.lnk` 전용 검사라는 근거는 아니다. IObit은 [Startup Guard가 자동 실행 변경을 감시한다](https://www.iobit.com/en/features-real-time-pc-protection-%26-security-guard-26.php)고 설명한다. 이번에 확인한 공식 자료에는 `Suspicious.Startup`의 개별 판정 조건이 없었다. 실시간 Startup Guard 설명을 이번 예약 Smart Scan의 세부 규칙과 동일시하지 않는다.

초기 대응에서는 같은 바로가기의 재작성을 막고 기능 검사를 통과했다. 이후 사용자가 제공한 격리 목록에서 실제 격리 대상이 `What the Port.lnk`임을 다시 확인했고, 1.1.5에서는 아래와 같이 레지스트리 등록으로 변경했다. 격리된 객체가 바로가기라는 사실만으로 EXE의 안전성이나 IObit의 세부 판정 조건까지 확정하지 않는다.

로그·해시·바로가기 대조 결과(`startup-cause-evidence.json`)와 로컬 검토 요청 자료는 `artifacts/security/antivirus-review-20261025-recurrence/`에 보관한다. 정확한 원인을 더 구분하려면 같은 EXE·같은 DB로 자동 실행 등록 유무 등을 비교하는 격리 환경 재현이나 제조사의 규칙 설명이 필요하다. 실제 시작프로그램 폴더의 `.lnk` 재등록, IObit Smart Scan 대조, 외부 제출은 하지 않았다. 파일 검사 0건이나 단순 재빌드만으로 해결됐다고 판단하지 않는다.

후속 사용자 요청으로 레지스트리 등록도 확인했다. 사용자·시스템 및 32비트 호환 위치의 `Run`·`RunOnce` 여섯 경로에서 앱 이름에 해당하는 항목이 없었다. 같은 탐지 EXE를 `HKCU\Software\Microsoft\Windows\CurrentVersion\Run`의 `What the Port` 값에 `REG_SZ` 형식으로 잠시 등록했다. 명령은 `"<EXE 전체 경로>" --background`이며, 정확한 값 읽기와 약 5초 후 해당 값만 삭제해 원래 미등록 상태로 복원하는 검증이 통과했다. EXE를 실행하지 않았고 검사 전후 해시도 같았다. 관찰 중 새 앱 관련 IObit 보고서는 없었지만 Smart Scan을 실행하지 않았으므로 백신 통과나 레지스트리 방식의 탐지 해결을 의미하지 않는다. 근거는 같은 로컬 폴더의 `registry-registration-check.json`에 보관한다.

### 1.1.5 · 자동 실행 등록 변경

Windows 로그인 시 시작은 현재 사용자 `HKCU\Software\Microsoft\Windows\CurrentVersion\Run`의 `What the Port` 값에 `REG_SZ` 명령 `"<EXE 전체 경로>" --background`로 등록한다. 사용자 설정을 저장할 때만 변경하고, 같은 명령은 다시 쓰지 않는다. 새 `.lnk`를 만들거나 `WScript.Shell`을 사용하지 않는다.

기존 시작프로그램 폴더의 앱 바로가기가 남아 있으면 설정에서 켜진 상태로 표시하고, 저장 시 레지스트리로 옮긴 뒤 해당 바로가기만 제거한다. 이전 도중 정리에 실패하면 기존 레지스트리 값과 형식을 복원한다. 끄면 앱의 레지스트리 값과 기존 앱 바로가기를 제거하며 다른 항목은 유지한다. 백신에 격리돼 현재 등록이 없는 경우에는 자동으로 재등록하거나 격리 파일을 복원하지 않는다.

최종 단일 EXE의 SHA-256은 `323400c20142bf8dbf49aa5f99be4c604b79ee557abed35ea26a0b714961ce99`다. IObit 13.5.0.1684 · DB 2638의 Manual / Right Scan에서 2개 개체 · 14초 · Completed · 탐지 0건을 확인했고 검사 전후 해시는 같았다. 일반·단일 EXE에서 Core 148개·UI 215개 검사가 통과했다.

최종 다운로드와 ZIP 내부 파일의 검사 기록은 [1.1.5 백신 검사 정보](https://seo-gali.github.io/what-the-port-win/downloads/ANTIVIRUS-INFO-1.1.5.json)에 공개한다. 이 결과는 해당 파일의 수동 검사이며, 실제 로그인 후의 자동 실행·시작 항목 Smart Scan 통과·오탐 확정·코드 서명 완료를 의미하지 않는다. 원본 보고서와 해시는 로컬 `artifacts/security/antivirus-review-1.1.5-registry/`에 보존한다.
## 단일 EXE

`powershell -NoProfile -ExecutionPolicy Bypass -File scripts/build-single-file.ps1`은 Core와 UI 코드를 하나의 일반 .NET 어셈블리로 컴파일한다. WPF 마크업·Geist 폰트·MIT/OFL 전문을 내장한다. 외부 DLL이나 폰트를 임시 폴더에 풀어내는 로더·압축기는 사용하지 않는다. `--licenses`로 라이선스를 열람할 수 있다. Windows의 .NET Framework 4.8은 필요하며, `wtp.exe` CLI는 선택 ZIP에 포함된다.

`test-single-file.ps1`은 Core·UI 회귀 검사, 실제 내장 폰트 해석, EXE 한 개뿐인 폴더에서 시작·재실행·트레이·조회·라이선스 표시를 검사한다. `verify-single-file.ps1`은 x64 메타데이터·내장 리소스 이름·외부 Core 참조 부재·SHA-256·Authenticode를 확인한다. `docs/downloads/EXE-INFO.json`은 이 확인 결과이며 악성코드 검사 결과가 아니다.

## 구현한 배포 절차

- `scripts/package.ps1`: 앱 소스·빌드 입력이 같고 기존 실행 파일의 해시가 일치하면 재빌드를 생략한다. 문서만 바뀌어도 EXE/DLL을 다시 컴파일하지 않는다. 패키지 입력·ZIP 해시까지 같으면 ZIP도 그대로 유지한다. 강제 재빌드는 `-Rebuild`.
- `scripts/verify-package.ps1`: 압축 파일의 SHA-256, 전체 항목, 필수 파일, 중복·경로 순회·뜻밖의 실행 파일, EXE/DLL의 Authenticode를 확인한다. 검사 보고서는 `artifacts/package-verification.json`. 악성코드 검사나 Chrome 평판 검사가 아니다.
- `scripts/sign.ps1`: Windows 인증서 저장소의 공인 코드 서명 인증서로 EXE 두 개·Core DLL에 SHA-256 서명과 타임스탬프를 적용한다. 이미 같은 인증서로 유효하게 서명된 파일은 다시 서명하지 않는다. `-SingleFile`이면 내장형 GUI EXE만 서명한다. PFX·암호·비밀 키 파일을 읽거나 저장하는 기능은 없다.
- `scripts/prepare-site.ps1`: 기본값은 신뢰된 서명과 타임스탬프가 없는 새 배포물의 준비를 거부한다. 미서명 시험 배포는 `-AllowUnsigned`를 명시해야 한다.
- 웹사이트 문구 수정만 할 때는 기존 ZIP을 재생성하지 않는다. 다운로드 주소·내용을 숨기거나 파일 확장자·보호 설정을 변경해 검사를 피하지 않는다.

## 로컬 시험 빌드

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File scripts/package.ps1
powershell -NoProfile -ExecutionPolicy Bypass -File scripts/prepare-site.ps1 -AllowUnsigned
```

`-AllowUnsigned`는 경고를 제거하지 않는다. 시험 배포임을 알고 쓰는 옵션이다. 인증서가 없다면 정식 서명 배포를 완료할 수 없다.

## 공인 인증서가 준비된 이후

1. 실제 게시자 명의의 코드 서명 인증서를 Windows 인증서 저장소에 설치한다. 인증서 구입·계정 생성은 별도 결정이다. 자체 서명 인증서를 사용자의 신뢰 목록에 추가하도록 요구하지 않는다.
2. 아래처럼 최초 패키지 빌드로 캐시를 만든 후 서명하고, 서명된 파일을 재컴파일하지 않고 최종 패키지를 만든다.
3. 유효한 백신 환경에서 해당 **최종 ZIP과 내부 파일**을 검사하고 결과를 기록한다. 현재 작업 PC의 Defender 비활성 상태를 검사 통과로 처리하지 않는다.
4. 사이트 준비가 성공한 동일 ZIP을 배포한다. 서명·검사 후 파일을 다시 수정하면 다시 검증한다.

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File scripts/package.ps1
$certificateThumbprint = Read-Host '설치한 공인 코드 서명 인증서의 공개 지문'
$timestampUrl = Read-Host '인증기관이 안내한 Authenticode 타임스탬프 URL'
.\scripts\sign.ps1 -CertificateThumbprint $certificateThumbprint -TimestampServer $timestampUrl
powershell -NoProfile -ExecutionPolicy Bypass -File scripts/build-single-file.ps1
.\scripts\sign.ps1 -SingleFile -CertificateThumbprint $certificateThumbprint -TimestampServer $timestampUrl
powershell -NoProfile -ExecutionPolicy Bypass -File scripts/verify-single-file.ps1 -RequireSignature
powershell -NoProfile -ExecutionPolicy Bypass -File scripts/package.ps1 -RequireSignature
powershell -NoProfile -ExecutionPolicy Bypass -File scripts/prepare-site.ps1
```

Windows PowerShell의 타임스탬프 공급자는 `http://` URL을 요구한다. 앱·ZIP 다운로드 주소는 계속 HTTPS다. 타임스탬프 URL은 인증기관의 실제 안내값을 사용한다.

[Microsoft Authenticode 서명 문서](https://learn.microsoft.com/en-us/powershell/module/microsoft.powershell.security/set-authenticodesignature?view=powershell-5.1)

## Google 소유권 확인과 검토

[Google Search Console](https://search.google.com/search-console/)에서 **URL 접두어** 속성 `https://seo-gali.github.io/what-the-port-win/`를 추가한다. `github.io` 도메인 전체의 DNS 소유권을 요구하는 속성은 선택하지 않는다.

소유권 확인에 Google이 발급한 HTML 파일 방식 또는 HTML 메타 태그 방식을 사용한다. HTML 파일은 `docs/`에 Google이 지정한 이름·내용 그대로 두고 배포한 후 확인한다. 메타 태그는 Google이 지정한 값을 홈페이지 head에 넣는다. 확인용 값은 게시에 필요한 공개 값이며 Google 계정 암호를 제공할 필요는 없다. 소유권 확인 후에도 확인 파일·태그는 유지한다.

**보안 문제** 보고서에 **Uncommon downloads**가 있다면 배포·서명·백신 검사 결과를 실제로 준비한 뒤 **검토 요청**을 사용한다. 재검토 여부·결과는 Google에서 결정한다. 보고서에 해당 문제가 없거나 검토가 진행 중이면 신청 완료·경고 해제를 주장하지 않는다.

사용자가 확인한 현재 보고서는 **감지된 문제 없음**이다. 사이트 소유권 확인은 완료됐지만 다운로드 파일의 평판 경고가 해제됐다는 의미는 아니다. 이 상태에서는 보안 문제 보고서에 검토 요청 버튼이 나타나지 않는다. Chrome의 **도움말 → 문제 신고**로 파일 URL과 경고 화면을 전달할 수 있지만 파일 재검토·응답·해제를 보장하는 절차는 아니다. [Chrome 문제 신고 안내](https://support.google.com/chrome/answer/95315?hl=ko).

[Google 소유권 확인 방법](https://support.google.com/webmasters/answer/9008080?hl=ko) · [보안 문제와 검토 절차](https://support.google.com/webmasters/answer/9044101?hl=ko)

### 검토 요청에 넣을 확인 정보

- 배포 페이지: `https://seo-gali.github.io/what-the-port-win/`
- 기본 EXE 주소: `https://seo-gali.github.io/what-the-port-win/downloads/WhatThePort.exe`
- 선택 ZIP 주소: `https://seo-gali.github.io/what-the-port-win/downloads/WhatThePort-Windows-x64.zip`
- 공개 소스: `https://github.com/seo-gali/what-the-port-win`
- 실제 SHA-256: `docs/downloads/SHA256SUMS.txt`
- 서명·파일 정보: `docs/downloads/EXE-INFO.json`, `docs/downloads/PACKAGE-INFO.json`
- 실제 백신 검사 결과와 검사 날짜: 검사한 후에만 기재
- 설명: Windows 로컬 TCP 리스너·사용자 프로세스를 표시하는 포터블 WPF 도구이며 자동 정리는 기본 Off. 네트워크 통신·텔레메트리·자동 업데이트·추가 소프트웨어 설치는 앱 기능에 포함하지 않음.

로컬 IObit 재검사 결과는 위 기록대로 안내하되, 코드 서명·제조사 판정·독립적인 백신 검사까지 완료됐다고 작성하지 않는다. 코드 서명·Google 심사 완료 전에는 Chrome 경고 해제가 미완료 상태다.
